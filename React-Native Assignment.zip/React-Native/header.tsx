import { Text, View } from "react-native"

export default function Header(): JSX.Element{

  return (
  
  <View style={{height:30, backgroundColor:"yellow"}}>

    <Text style={{textAlign:"center"}}>
        I am header
    </Text>
    
  </View>
 
 )
}


