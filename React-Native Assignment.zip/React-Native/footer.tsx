import { Text, View } from "react-native"

export default function Footer(): JSX.Element{

  return (
  
  <View style={{height:200,backgroundColor:"orange"}}>

    <Text style={{ textAlign:"center"}}>
        I am footer
    </Text>
    
  </View>
 
 )
}


