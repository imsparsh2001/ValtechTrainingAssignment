import {createRoot} from  "react-dom/client";
import React from "react";
import App from "./components/app";



createRoot(document.getElementById("root")).render(<App/>);